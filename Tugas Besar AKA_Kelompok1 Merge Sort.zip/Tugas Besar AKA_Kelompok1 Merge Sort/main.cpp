#include "merge.h"
#include "bubble.h"
#include <chrono>

void printArray(int arr[], int n) {
    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << ' ';
    }
}

void printArray(long long arr[], int n) {
    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << ' ';
    }
}

void generateArray(int arr[], int n)
{
    for(int i = 0; i < n; i++)
    {
        arr[i] = rand()%100; // Generate number between 0 to 99
    }
}

void runningTime() {
    int n[] = {10, 100, 1000, 10000, 100000};
    int n_size = sizeof(n) / sizeof(n[0]);

    cout << "Merge Sort" << endl;
    for (int i = 0; i < n_size; i++)
    {
        chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
        int arr[n[i]];
        generateArray(arr, n[i]);
        mergeSort(arr, 0, n[i]-1);
        chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
        cout << "Time difference N = " << n[i] << " : " <<
            chrono::duration_cast<chrono::microseconds>(end - begin).count() << " microseconds" << endl;
    }

    cout << "Bubble Sort" << endl;
    for (int i = 0; i < n_size; i++)
    {
        chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
        int arr[n[i]];
        generateArray(arr, n[i]);
        bubbleSort(arr, n[i]);
        chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
        cout << "Time difference N = " << n[i] << " : " <<
            chrono::duration_cast<chrono::microseconds>(end - begin).count() << " microseconds" << endl;
    }
}

int main()
{
    int n[] = {10, 20};
    int n_size = sizeof(n) / sizeof(n[0]);

    cout << "CONTOH HASIL SORTING MERGE SORT" << endl;
    for (int i = 0; i < n_size; i++)
    {
        int arr[n[i]];
        generateArray(arr, n[i]);
        cout << "Array sebelum di sort: ";
        printArray(arr, n[i]);
        cout << endl;

        mergeSort(arr, 0, n[i]-1);
        cout << "Array setelah dimerge sort: ";
        printArray(arr, n[i]);
        cout << endl;
    }

    cout << "CONTOH HASIL SORTING BUBBLE SORT" << endl;
    for (int i = 0; i < n_size; i++)
    {
        int arr[n[i]];
        generateArray(arr, n[i]);
        cout << "Array sebelum di sort: ";
        printArray(arr, n[i]);
        cout << endl;

        bubbleSort(arr, n[i]);
        cout << "Array setelah dibubble sort: ";
        printArray(arr, n[i]);
        cout << endl;
    }

    cout << endl << "ANALISIS PERBANDINGAN RUNNING TIME " << endl;
    runningTime();
    return 0;
}
