#ifndef MERGE_H_INCLUDED
#define MERGE_H_INCLUDED

#include <iostream>

using namespace std;

void merge(int arr[], int left, int middle, int right);
void mergeSort(int arr[], int left, int right);

#endif // MERGE_H_INCLUDED
