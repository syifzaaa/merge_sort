#include "merge.h"

void merge(int arr[], int left, int middle, int right)
{
    int nLeft, nRight;
    nLeft = middle-left+1;
    nRight = right-middle;

    int arrLeft[nLeft], arrRight[nRight];
    for (int i = 0; i < nLeft; i++)
    {
        arrLeft[i] = arr[left+i];
    }
    for (int i = 0; i < nRight; i++)
    {
        arrRight[i] = arr[middle+1+i];
    }

    int i = 0;
    int j = 0;
    int k = left;

    while (i < nLeft && j < nRight)
    {
        if (arrLeft[i] <= arrRight[j])
        {
            arr[k] = arrLeft[i];
            i++;
        }
        else
        {
            arr[k] = arrRight[j];
            j++;
        }
        k++;
    }

    while (i < nLeft)
    {
        arr[k] = arrLeft[i];
        i++;
        k++;
    }
    while (j < nRight)
    {
        arr[k] = arrRight[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int left, int right)
{
    if (left >= right) {
        return;
    }
    int middle = (left+right-1)/2;
    mergeSort(arr, left, middle);
    mergeSort(arr, middle+1, right);
    merge(arr, left, middle, right);

}
